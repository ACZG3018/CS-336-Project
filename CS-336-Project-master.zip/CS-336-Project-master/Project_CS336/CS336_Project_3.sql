CREATE DATABASE cs_336_project_3;
use cs_336_project_3;
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(50),
    email VARCHAR(50),
    address VARCHAR(100),
    phone VARCHAR(20),
    password VARCHAR(25)
);

CREATE TABLE vehicles (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    type VARCHAR(20) NOT NULL
);

CREATE TABLE cars (
    vehicle_id INT PRIMARY KEY,
    body_style VARCHAR(50),
    num_doors INT,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE
);

CREATE TABLE trucks (
    vehicle_id INT PRIMARY KEY,
    num_wheels INT,
    axle_config VARCHAR(20),
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE
);

CREATE TABLE motorcycles (
    vehicle_id INT PRIMARY KEY,
    has_sidecar INT,
    handlebar_style VARCHAR(20),
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE
);

CREATE TABLE auctions (
    auction_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    seller_id INT NOT NULL,
    start_price DOUBLE NOT NULL,
    min_price DOUBLE NOT NULL,
    bid_increment DOUBLE NOT NULL DEFAULT 1.0,
    current_highest_bid DOUBLE DEFAULT NULL,
    current_highest_bidder INT DEFAULT NULL,
    reserve_price DOUBLE DEFAULT NULL,
    end_time DATETIME NOT NULL,
    is_active INT DEFAULT 1,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(user_id)
);

CREATE TABLE bids (
    bid_id INT AUTO_INCREMENT PRIMARY KEY,
    auction_id INT NOT NULL,
    bidder_id INT NOT NULL,
    bid_amount DECIMAL(10,2) NOT NULL,
    max_auto_bid DECIMAL(10,2) DEFAULT NULL,
    bid_time DATETIME DEFAULT CURRENT_TIMESTAMP,

    retracted INT DEFAULT 0,
    cancelled_by_seller INT DEFAULT 0,

    FOREIGN KEY (auction_id) REFERENCES auctions(auction_id) ON DELETE CASCADE,
    FOREIGN KEY (bidder_id) REFERENCES users(user_id)
);

CREATE TABLE auto_bids (
	auctionbid_id INT AUTO_INCREMENT PRIMARY KEY,
    auction_id INT NOT NULL,
    bidder_id INT NOT NULL,
    max_bid DECIMAL(10,2) NOT NULL,
    increment DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (auction_id) REFERENCES auctions(auction_id) ON DELETE CASCADE,
    FOREIGN KEY (bidder_id) REFERENCES users(user_id)
);

